# SAFETY SENTRY release full_data_20260530: files, call links, label provenance, split documentation

Prepared 24 October 2026. Raw files are unmodified copies of the files we scored from (identical SHA-256 to the public repository `safesentry/SAFETY-SENTRY`, `data/`).

## Contents

| File | Content |
|---|---|
| `test_1436.json`, `train_7767.json`, `mailu_ood_198.json`, `manifest.json` | the release, original format (point 1) |
| `call_links.csv` | one row per call (9,401), linking fields (point 2), see below |
| `split_documentation/` | `data_README.md`, `DATA_AND_LICENSES.md`, `TASK_AUTHORING.md` (task generator prompt with templates T1-T7), repository `README` (point 4) |

`call_links.csv` columns: `dataset_idx` (same index as our score files: position in the split file), `split`, `service`, `ground_truth`, `source` (source benchmark or internal pipeline), `task_sha16` (hash of the user-task text), `task_id`, `template` (T1-T7, parsed from `task_id`), `step_index`, `session_length`, `persona_label`, `persona_axis`, `origin` (Mailu persona axis), `user_prompt_sha16`, `full_prompt_sha16` (system + user message), `risk_class`, `risk_family`, `empirical_risk_family`, `decision_count`, `original_decision`. It also has counts of calls with the same task, user prompt or full prompt in each split (`n_same_<task|user_prompt|full_prompt>_in_<test|train|mailu>`), the set of labels given to an identical full prompt, and a conflict flag.

## Fields not in the release

- **Trajectory, episode or session ID:** none as such. `task_id` together with `step_index` and `session_length` identifies the step within a generated task. These are present for 482 test and 2,944 train calls, which are the internal pipeline records. The adapted benchmark records (When2Call, AT-Bench, AgentHarm, TS-Bench) have only the task text.
- **Original item ID of the source benchmark:** not present. Only `source` is.
- **Label provenance (point 3):** not present. The release has only the final label (`meta.decision`). The two LLM annotators' labels, disagreement or arbitration flags, taxonomy triggers and the human-audit labels are not in the files or the repository. The closest fields are:
  - `risk_class` (taxonomy class, empty for about 40%);
  - `original_decision` (Mailu only: 4 records with a changed label);
  - `decision_count`, whose meaning is not documented.

  The annotator labels would have to be requested from the corpus authors (Chen et al., 2026).

## Split documentation (point 4)

The repository and the data card do not say how the 7,767 / 1,436 split was drawn. `DATA_AND_LICENSES.md` says only "9,203 records split into 7,767 training and 1,436 test records". Mailu is held out by service. The data show that the in-domain split was **not by task or trajectory**:

| | Test | Train | Mailu |
|---|---|---|---|
| Calls | 1,436 | 7,767 | 198 |
| Distinct task texts | 801 | 3,804 | 70 |
| Calls whose task text has more than one call in the split | 798 | 4,837 | 178 |
| Most calls from one task | 26 | 42 | 9 |

- Test calls whose task text also occurs in train: **969 of 1,436**.
- Test calls whose full prompt (system + user message) is identical to a train call: **640**.
- Train calls whose full prompt is identical to a test call: **650**.
- Identical full prompts with different labels (counted over all splits): 50 test, 100 train and 15 Mailu calls are involved. This is real label noise for point 3.
- Mailu shares no task text with test or train.

## Two one-line answers (point 5)

**(a)** Yes. One user task produces several calls (one per step, up to 26 in test and 42 in train), and 969 test calls share their task with train calls, 640 of them with an identical prompt.

**(b)** Yes, the internal tasks are generated from templates T1-T7 by an authoring agent (`TASK_AUTHORING.md`). Generation happened before the split, since calls from the same task and even identical prompts sit on both sides. The order is not documented explicitly; it is inferred from the data.

## Consequence for our analyses (for discussion)

- **Paper:** the 50/50 calibration-test splits of the test split are drawn by call, so related calls from one task (163 multi-call tasks) sit on both sides.
- **Confirmatory evaluation:** the "untouched" train split contains 650 calls identical to test calls on which the frozen policies were calibrated. These are 8.4% of the train calls, by label 302 execute / 230 ask / 146 refuse (based on identical user prompts).
- A sensitivity analysis by task cluster (for example, grouped splits on `task_sha16`, or excluding the duplicated train calls) would quantify the effect. It is outside the frozen protocol and would have to be reported as such.
